const $=s=>document.querySelector(s),LS=localStorage,sleep=ms=>new Promise(r=>setTimeout(r,ms)),rnd=n=>1+Math.floor(Math.random()*n);
const COL={brown:'#8b5a2b',sky:'#3fb8f0',pink:'#e05ab0',orange:'#f39a2b',red:'#e0403a',yellow:'#f2d330',green:'#35b862',navy:'#3b5bdb'};
const T=`Эхлэл|go|||🏁
Баянхонгор|p|brown|60|🐫
Сюрприз|c|||❓
Архангай|p|brown|60|🐎
Татвар|t||200|🪙
Чингис хаан нисэх|r||200|✈️
Өвөрхангай|p|sky|100|🐴
Сюрприз|c|||❓
Төв|p|sky|100|🏛️
Говь-Алтай|p|sky|120|⛰️
Шорон|jail|||⛓️
Завхан|p|pink|140|🏔️
Сүхбаатар|p|pink|140|🌾
Дорноговь|p|pink|160|🐪
Замын-Үүд|r||200|🚂
Дундговь|p|orange|180|⛺
Сюрприз|c|||❓
Говьсүмбэр|p|orange|180|🏯
Хөвсгөл|p|orange|200|🏞️
Ховд|p|orange|200|🦅
Аялал|park|||🌴
Баян-Өлгий|p|red|220|🦅
Сюрприз|c|||❓
Увс|p|red|220|🌊
Булган|p|red|240|⛰️
Эрдэнэт төмөр зам|r||200|🚃
Сэлэнгэ|p|yellow|260|🌲
Орхон|p|yellow|260|🏭
Сюрприз|c|||❓
Дархан-Уул|p|yellow|280|🏗️
Явах|gj|||🏃
Хэнтий|p|green|300|🦌
Дорнод|p|green|300|🛢️
Сюрприз|c|||❓
Сүхбаатар аймаг|p|green|320|🌄
Мөрөн нисэх|r||200|🛩️
Сюрприз|c|||❓
Өмнөговь|p|navy|350|🦖
Татвар|t||100|🪙
Улаанбаатар|p|navy|400|🏙️`.split('\n').map(l=>{const[n,t,g,pr,ic]=l.split('|');return{n,t,g,pr:+pr||0,ic,own:null,h:0}});
const CARDS=[['Наадмын шагнал +150',150],['Торгууль -100',-100],['Эхлэл рүү яв (+200)','go'],['Шорон руу яв','jail'],['Найз тань 50 өглөө',50],['Малын үнэ өсөв +100',100],['Засварын зардал -80',-80],['Аялал руу яв','park']];
const P=[{n:LS.getItem('name')||'Beatna',e:'🐸',img:LS.getItem('avatar')||'',h:'👑',me:1},{n:'Bold',e:'🐻',h:'🎩'},{n:'Sarnai',e:'🦊',h:'🧢'},{n:'Zaya',e:'🐯',h:'🕶️'}].map(p=>({...p,m:1500,pos:0,out:0,skip:0}));
let cur=0,phase='wait',micOn=false,stream=null;
const cell=i=>i<=10?[11,11-i]:i<=20?[11-(i-10),1]:i<=30?[1,1+(i-20)]:[1+(i-30),11];
const av=p=>p.img?`<img src="${p.img}">`:p.e;
// ---- Самбар
const B=$('#board');T.forEach((t,i)=>{const[r,c]=cell(i),d=document.createElement('div');d.className='t '+(t.t==='c'?'c':'');d.style.gridArea=`${r}/${c}`;d.id='t'+i;
 d.innerHTML=(t.g?`<i class="bar" style="background:${COL[t.g]}"></i>`:'')+`<span class="ic">${t.ic}</span><b>${t.n}</b>${t.pr?`<small>${t.pr}</small>`:''}<span class="hs"></span><div class="tk"></div>`;B.appendChild(d)});
const OC=['#e9b949','#3fb8f0','#f39a2b','#35b862'];
function draw(){
 $('#players').innerHTML=P.map((p,i)=>`<div class="pc${i===cur?' turn':''}${p.out?' out':''}${p.me&&micOn&&window.spk?' speak':''}"><div class="av">${av(p)}<span class="hat">${p.h}</span></div><div><b>${p.n}</b><span class="m">${p.m} MNT</span><br><span class="o">${T.filter(t=>t.own===p).length} ӨМЧ</span></div></div>`).join('');
 T.forEach((t,i)=>{const d=$('#t'+i);d.classList.toggle('o',t.own!=null);d.style.borderColor=t.own?OC[P.indexOf(t.own)]:'';d.querySelector('.hs').textContent=t.h?'🏠'.repeat(t.h):'';
  d.querySelector('.tk').innerHTML=P.map((p,k)=>p.pos===i&&!p.out?`<i style="border-color:${OC[k]}">${av(p)}</i>`:'').join('')});
 const t=T[P[0].pos],me=P[0],mine=cur===0&&phase==='act';
 $('#roll').disabled=!(cur===0&&phase==='roll');
 $('#buy').disabled=!(mine&&!t.own&&'pr'.includes(t.t)&&me.m>=t.pr);
 $('#build').disabled=!(mine&&t.own===me&&t.t==='p'&&full(t)&&t.h<4&&me.m>=Math.ceil(t.pr/2));
 $('#end').disabled=!mine;
}
const full=t=>T.filter(x=>x.g===t.g).every(x=>x.own===t.own);
const rent=t=>{if(t.t==='r')return 25*T.filter(x=>x.t==='r'&&x.own===t.own).length;const b=Math.round(t.pr/10);return t.h?b*(1+2*t.h):full(t)?b*2:b};
// ---- Лог / чат
function log(t,n){const d=document.createElement('div');d.innerHTML=n?'<b></b> <span></span>':'<span class="s"></span>';
 if(n){d.children[0].textContent=n+':';d.children[1].textContent=t}else d.firstChild.textContent=t;$('#log').appendChild(d);$('#log').scrollTop=1e9}
const bc='BroadcastChannel' in window?new BroadcastChannel('mono-room'):null;
$('#cf').onsubmit=e=>{e.preventDefault();const v=$('#ci').value.trim();if(!v)return;log(v,P[0].n);bc&&bc.postMessage({n:P[0].n,t:v});$('#ci').value='';
 if(Math.random()<.4)setTimeout(()=>{const b=P[1+rnd(3)-1];log(['Амжилт!','Ёстой!','Аймгаа надад зарчих 😄','Шоо сайн өнхрөөрэй'][rnd(4)-1],b.n)},900)};
if(bc)bc.onmessage=e=>log(e.data.t,e.data.n);
// ---- Микрофон
$('#mic').onclick=async()=>{if(!micOn){try{stream=stream||await navigator.mediaDevices.getUserMedia({audio:true})}catch{log('Микрофонд хандах эрх олгоно уу');return}
 stream.getAudioTracks().forEach(t=>t.enabled=true);micOn=true;watch()}else{stream.getAudioTracks().forEach(t=>t.enabled=false);micOn=false;window.spk=false}
 $('#mic').className='mic '+(micOn?'on':'off');$('#mic').textContent=micOn?'🎙️':'🔇';draw()};
function watch(){const c=new (window.AudioContext||webkitAudioContext)(),a=c.createAnalyser();c.createMediaStreamSource(stream).connect(a);const b=new Uint8Array(a.fftSize);
 (function l(){if(!micOn){c.close();return}a.getByteTimeDomainData(b);let m=0;for(const v of b)m=Math.max(m,Math.abs(v-128));const s=m>14;if(s!==!!window.spk){window.spk=s;draw()}requestAnimationFrame(l)})()}
// ---- Шоо ба явц
const PIP={1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]};
const die=(el,n)=>{el.innerHTML=[...Array(9)].map((_,i)=>`<span class="${PIP[n].includes(i)?'on':''}"></span>`).join('');el.classList.remove('roll');void el.offsetWidth;el.classList.add('roll')};
die($('#d1'),1);die($('#d2'),1);
function pay(p,amt,to){p.m-=amt;if(to)to.m+=amt;if(p.m<0){p.out=1;T.forEach(t=>{if(t.own===p){t.own=null;t.h=0}});log(`${p.n} дампуурлаа!`);const a=P.filter(x=>!x.out);if(a.length===1){log(`🏆 ${a[0].n} ялалаа!`);phase='end'}}}
async function move(p){const a=rnd(6),b=rnd(6);die($('#d1'),a);die($('#d2'),b);log(`${p.n} ${a+b} шидлээ`);await sleep(500);
 for(let i=0;i<a+b;i++){p.pos=(p.pos+1)%40;if(p.pos===0){p.m+=200;log(`${p.n} Эхлэлээр өнгөрч +200`)}draw();await sleep(170)}
 land(p)}
function land(p){const t=T[p.pos];
 if('pr'.includes(t.t)&&t.pr){if(!t.own){if(!p.me&&p.m>=t.pr+250)buy(p);else if(p.me)log(`${t.n} — ${t.pr} MNT. Худалдаж авах уу?`)}
  else if(t.own!==p){const r=rent(t);log(`${p.n} → ${t.own.n}: түрээс ${r}`);pay(p,r,t.own)}}
 else if(t.t==='t'){log(`${p.n} татвар ${t.pr} төллөө`);pay(p,t.pr)}
 else if(t.t==='gj'){p.pos=10;p.skip=1;log(`${p.n} шорондоо орлоо`)}
 else if(t.t==='c'){const[x,v]=CARDS[rnd(CARDS.length)-1];log(`Сюрприз: ${x}`);
  if(v==='go'){p.pos=0;p.m+=200}else if(v==='jail'){p.pos=10;p.skip=1}else if(v==='park')p.pos=20;else v<0?pay(p,-v):p.m+=v}
 draw()}
function buy(p){const t=T[p.pos];t.own=p;p.m-=t.pr;log(`${p.n} ${t.n}-г худалдан авлаа.`);draw()}
async function next(){if(phase==='end')return;do cur=(cur+1)%4;while(P[cur].out);draw();const p=P[cur];
 if(p.skip){p.skip--;log(`${p.n} шоронд байна, ход алгасав`);await sleep(700);return next()}
 if(p.me){phase='roll';draw();return}
 phase='bot';await sleep(800);await move(p);await sleep(600);
 const t=T[p.pos];if(t.own===p&&t.t==='p'&&full(t)&&t.h<4&&p.m>=Math.ceil(t.pr/2)+400){p.m-=Math.ceil(t.pr/2);t.h++;log(`${p.n} ${t.n} дээр байшин барив`);draw()}
 await sleep(500);next()}
$('#roll').onclick=async()=>{phase='moving';draw();await move(P[0]);if(phase!=='end')phase='act';draw()};
$('#buy').onclick=()=>buy(P[0]);
$('#build').onclick=()=>{const t=T[P[0].pos];P[0].m-=Math.ceil(t.pr/2);t.h++;log(`${t.n} дээр байшин барилаа`);draw()};
$('#end').onclick=()=>next();
log('Тавтай морил! Шоогоо өнхрүүлээрэй.');phase='roll';draw();
